-- ============================================================
-- NPC Action Points - client.lua
-- ============================================================

local spawnedPeds  = {}
local createdBlips = {}

-- ────────────────────────────────────────────────────────────
-- NPC Spawnen
-- ────────────────────────────────────────────────────────────

local function LoadModel(model)
    local hash = GetHashKey(model)
    RequestModel(hash)
    while not HasModelLoaded(hash) do Wait(50) end
    return hash
end

local function SpawnNPC(point)
    local hash = LoadModel(point.npc.model)
    local ped  = CreatePed(4, hash,
        point.npc.coords.x,
        point.npc.coords.y,
        point.npc.coords.z - 1.0,
        point.npc.coords.w,
        false, true
    )
    SetEntityInvincible(ped, point.npc.invincible)
    FreezeEntityPosition(ped, point.npc.frozen)
    SetBlockingOfNonTemporaryEvents(ped, point.npc.blockEvents)
    SetPedCanRagdollFromPlayerImpact(ped, false)
    SetPedFleeAttributes(ped, 0, false)
    SetEntityAsMissionEntity(ped, true, true)

    if point.npc.scenario then
        TaskStartScenarioInPlace(ped, point.npc.scenario, 0, true)
    elseif point.npc.animDict and point.npc.animName then
        RequestAnimDict(point.npc.animDict)
        while not HasAnimDictLoaded(point.npc.animDict) do Wait(50) end
        TaskPlayAnim(ped, point.npc.animDict, point.npc.animName, 8.0, -8.0, -1, 1, 0, false, false, false)
    end

    SetModelAsNoLongerNeeded(hash)
    return ped
end

-- ────────────────────────────────────────────────────────────
-- Blip erstellen
-- ────────────────────────────────────────────────────────────

local function CreateBlip(point)
    if not point.blip or not point.blip.enabled then return end
    local blip = AddBlipForCoord(point.npc.coords.x, point.npc.coords.y, point.npc.coords.z)
    SetBlipSprite(blip, point.blip.sprite)
    SetBlipColour(blip, point.blip.color)
    SetBlipScale(blip, point.blip.scale)
    SetBlipAsShortRange(blip, true)
    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString(point.blip.label)
    EndTextCommandSetBlipName(blip)
    return blip
end

-- ────────────────────────────────────────────────────────────
-- Marker & Label & Helptext
-- ────────────────────────────────────────────────────────────

local function DrawMarker3D(coords)
    local m = Config.Marker
    DrawMarker(m.Type,
        coords.x, coords.y, coords.z - 1.0,
        0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
        m.Scale.x, m.Scale.y, m.Scale.z,
        m.Color.r, m.Color.g, m.Color.b, m.Color.a,
        m.BobUpAndDown, false, 2, false, nil, nil, false
    )
end

local function DrawLabel(coords, text)
    local cam  = GetGameplayCamCoords()
    local dist = #(cam - vector3(coords.x, coords.y, coords.z))
    if dist > Config.DrawDistance then return end
    SetDrawOrigin(coords.x, coords.y, coords.z + 1.25, 0)
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    SetTextFont(0)
    SetTextScale(0.35, 0.35)
    SetTextColour(255, 255, 255, 255)
    SetTextOutline()
    SetTextCentre(true)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function DrawHelpText(text)
    BeginTextCommandDisplayHelp("STRING")
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayHelp(0, false, true, -1)
end

-- ────────────────────────────────────────────────────────────
-- Command ausführen
-- ────────────────────────────────────────────────────────────

local function RunCommand(point)
    -- Im Chat anzeigen wenn visible = true
    if point.visible then
        TriggerEvent("chatMessage", GetPlayerName(PlayerId()), {255, 255, 255}, point.command)
    end
    -- Command ausführen (ohne führendes "/")
    ExecuteCommand(point.command:gsub("^/", ""))
end

-- ────────────────────────────────────────────────────────────
-- Haupt-Tick
-- ────────────────────────────────────────────────────────────

Citizen.CreateThread(function()
    while true do
        local playerCoords = GetEntityCoords(PlayerPedId())
        local sleep        = 500

        for _, point in ipairs(Config.ActionPoints) do
            local npcCoords = vector3(point.npc.coords.x, point.npc.coords.y, point.npc.coords.z)
            local dist      = #(playerCoords - npcCoords)

            if dist < Config.DrawDistance then
                sleep = 0

                DrawLabel(point.npc.coords, point.label)
                DrawMarker3D(point.npc.coords)

                if dist < Config.InteractDistance then
                    DrawHelpText(point.helpText)

                    if IsControlJustReleased(0, Config.InteractKey) then
                        RunCommand(point)
                    end
                end
            end
        end

        Wait(sleep)
    end
end)

-- ────────────────────────────────────────────────────────────
-- Initialisierung
-- ────────────────────────────────────────────────────────────

AddEventHandler("onClientResourceStart", function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end
    Wait(1000)

    for _, point in ipairs(Config.ActionPoints) do
        spawnedPeds[point.id]  = SpawnNPC(point)
        createdBlips[point.id] = CreateBlip(point)
    end
end)

-- ────────────────────────────────────────────────────────────
-- Cleanup
-- ────────────────────────────────────────────────────────────

AddEventHandler("onClientResourceStop", function(resourceName)
    if GetCurrentResourceName() ~= resourceName then return end

    for _, ped in pairs(spawnedPeds) do
        if DoesEntityExist(ped) then DeleteEntity(ped) end
    end
    for _, blip in pairs(createdBlips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
    end
end)
