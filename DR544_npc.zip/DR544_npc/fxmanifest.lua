fx_version 'cerulean'
game 'gta5'

name        'npc_actionpoints'
description 'NPC Aktionspunkte mit Command-System'
version     '1.0.0'

shared_scripts {
    'config.lua',
}

client_scripts {
    'client.lua',
}
