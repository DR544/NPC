Config = {}

Config.DrawDistance     = 15.0  -- Ab wann Marker & Label sichtbar sind
Config.InteractKey      = 38    -- 38 = E-Taste
Config.InteractDistance = 2.5   -- Wie nah der Spieler sein muss

Config.Marker = {
    Type  = 1,
    Scale = { x = 0.5, y = 0.5, z = 0.5 },
    Color = { r = 255, g = 165, b = 0, a = 180 },
    BobUpAndDown = true,
}

-- ══════════════════════════════════════════════════════════════
--  AKTIONSPUNKTE
--
--  Spieler drückt E → der "command" wird direkt ausgeführt.
--  visible = true  → Befehl erscheint im Chat sichtbar
--  visible = false → Befehl wird still ausgeführt
-- ══════════════════════════════════════════════════════════════
Config.ActionPoints = {

    -- Beispiel NPC
    {
        id       = "immo_markt",
        label    = "John Mcgill",
        helpText = "[E] Immobilien Markt",

        npc = {
            model       = "cs_andreas",
            coords      = vector4(-708.54, 271.97, 83.15, 211.38),
            scenario    = "WORLD_HUMAN_COP_IDLES",
            invincible  = true,
            frozen      = true,
            blockEvents = true,
        },

        blip = {
            enabled = true,
            sprite  = 350,
            color   = 3,
            scale   = 0.8,
            label   = "Immo Markt",
        },

        -- Dieser eine Command wird ausgeführt wenn der Spieler E drückt
        command = "/classifieds",
        visible = false,  -- true = im Chat sichtbar, false = still
    },

    -- Vorlage für weitere NPCs:
    {
        id       = "buyring_npc",
        label    = "Tommy Demarco",
        helpText = "[E] Interagieren",

        npc = {
            model       = "a_m_m_business_01",
            coords      = vector4(-623.52, -230.18, 38.06, 130.33),
            scenario    = "WORLD_HUMAN_STAND_IMPATIENT",
            invincible  = true,
            frozen      = true,
            blockEvents = true,
        },

        blip = {
            enabled = true,
            sprite  = 306,
            color   = 1,
            scale   = 1,
            label   = "Ring",
        },

        command = "/buyring",
        visible = false,
    },
}


    -- scheiss script